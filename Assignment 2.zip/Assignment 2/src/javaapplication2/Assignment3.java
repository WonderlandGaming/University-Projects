/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package javaapplication2;

import java.util.Scanner;

public class Assignment3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        System.out.print("Enter three sides: ");
        int a = input.nextInt();
        int b = input.nextInt();
        int c = input.nextInt();

        // Check if it's a valid triangle first
        if (a + b <= c || a + c <= b || b + c <= a) {
            System.out.println("Not a valid triangle");
        } else {
            // Nested if statements for triangle types
            if (a == b && b == c) {
                System.out.println("Equilateral");
            } else {
                if (a == b || b == c || a == c) {
                    System.out.println("Isosceles");
                } else {
                    System.out.println("Scalene");
                }
            }
        }
    }
}