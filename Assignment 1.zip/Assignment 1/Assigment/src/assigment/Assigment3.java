/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package assigment;

import java.util.Scanner;

public class Assigment3 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter three integer scores: ");
        int score1 = input.nextInt();
        int score2 = input.nextInt();
        int score3 = input.nextInt();

        // Use 3.0 to ensure floating-point division
        double average = (score1 + score2 + score3) / 3.0;
        long roundedAvg = Math.round(average);

        System.out.println(roundedAvg);
        System.out.printf("%.2f\n", average);
    }
}
