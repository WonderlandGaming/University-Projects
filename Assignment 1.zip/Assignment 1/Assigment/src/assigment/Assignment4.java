/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package assigment;

import java.util.Scanner;

public class Assignment4 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        System.out.print("Enter number of days: ");
        int totalDays = input.nextInt();

        int weeks = totalDays / 7;
        int remainingDays = totalDays % 7;

        System.out.println(weeks + " weeks and " + remainingDays + " days.");
    }
}
